package com.example.urlHitCounterApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlHitCounterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
